<?php
// This can be the same as index.php for simplicity
// Redirect to index.php for login
header("Location: index.php");
exit();
?>
